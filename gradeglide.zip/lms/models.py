from django.db import models

class Course(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Student(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Homework(models.Model):
    course = models.ForeignKey(Course, related_name='homeworks', on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    deadline = models.DateField()

    def __str__(self):
        return f"{self.title} ({self.course.name})"

class Submission(models.Model):
    homework = models.ForeignKey(Homework, related_name='submissions', on_delete=models.CASCADE)
    student = models.ForeignKey(Student, related_name='submissions', on_delete=models.CASCADE)
    submitted_at = models.DateTimeField(auto_now_add=True)
    grade = models.CharField(max_length=5, blank=True, null=True)
    file = models.FileField(upload_to='submissions/', null=True, blank=True)


    def __str__(self):
        return f"{self.student.name} - {self.homework.title} - Grade: {self.grade or 'Not graded'}"
