from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'), 
     path('', views.submit_homework, name='home'),
    path('submit-homework/', views.submit_homework, name='submit_homework'),
  
    path('success/', views.success, name='success'),  # a success page after submission (optional)
 
 
 
]
