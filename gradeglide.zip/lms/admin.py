from django.contrib import admin
from .models import Course, Student, Homework, Submission

admin.site.register(Course)
admin.site.register(Student)
admin.site.register(Homework)
admin.site.register(Submission)
